# define punctuation
punctuations = " "

my_str = open('testcopy1.txt','r')
test = file.read(my_str)
file = open('outputnew4.txt','w')

# To take input from the user
# my_str = input("Enter a string: ")

# remove punctuation from the string
no_punct = ""
for char in test:
   if char not in punctuations:
       no_punct = no_punct + char

# display the unpunctuated string
print(no_punct)
file.write(no_punct)