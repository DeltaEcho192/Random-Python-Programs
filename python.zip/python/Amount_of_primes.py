from time import clock
# declere most of the varibles and lists
totallist = []
num = 2
i = 0
amountinput = 0
amountrange = 12
totallist.append(3)
totallist.append(5)
totallist.append(7)
totallist.append(11)
totallist.append(13)

amountinput = int(input("Please enter the amount: "))
# This part of the code is the part to get a list of
# prime numbers to be used later

# The number is the while statment can be changed
# to the wanted amount of numbers to be calculated
at = clock()
while num != amountinput:
    # Add 1 to the previous so the same number is not repeted
    num = num + 1
    # For loop to calculate prime nubers
    for i in range(2, 13):
        # If num remainder is 0 then dont do anything
        if (num % i) == 0:
            break
    else:
        # If num remainder is not 0 then it adds the number to the second list
        totallist.append(num)
et = clock()
runtime = et-at
print(len(totallist))
print(runtime)