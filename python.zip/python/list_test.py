mylist=[]

e=50
i=-1
t=0
while i < e:
    mylist.append(t)
    i=i+1
    t=t+1
print (mylist)
