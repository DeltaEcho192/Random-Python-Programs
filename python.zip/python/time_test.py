import time
from time import strftime
from time import clock
test = time.clock()
print(test)
num = 0
control = "11:52:00"
localtime = strftime("%H:%M:%S")
print(localtime)

et = clock()
while localtime != control:
    num=num+1
    localtime = strftime("%H:%M:%S")
else:
    print("it is 12 pm")
at = clock()
runtime = at-et
print(runtime)