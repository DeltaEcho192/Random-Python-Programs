cost=150
amount=0
total=0

amount=int(input())