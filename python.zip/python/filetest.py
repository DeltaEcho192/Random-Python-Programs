f=open('testcopy1.txt','r')
print(f)
print(file.read(f))