f = open("final_output.txt", "r")
output = open("final_output2.txt", "w")

output.write(f.read().replace("latest-news-topic-link","").replace(">",""))
f.close()
output.close()