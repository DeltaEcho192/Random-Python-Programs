f = open("test_output3.txt", "r")
output = open("final_output.txt", "w")

output.write(f.read().replace("><h4 class=","").replace("</h4></a><time>",""))
f.close()
output.close()