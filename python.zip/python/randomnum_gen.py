from random import shuffle
from time import clock
import random

#This is a basic Random generater
et = clock()
test = random.randrange(1,10)

print(test)


#This randomly shuffles the list using the shuffle command

listtest = []
e=10
i=0
while i != e:
    listtest.append(i)
    i=i+1
    
shuffle(listtest)
print(listtest)
at = clock()
runtime = at-et
print(runtime)