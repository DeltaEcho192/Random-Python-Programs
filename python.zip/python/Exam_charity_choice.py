charitychoice = 0
bill = 0
donation = 0
total = 0
charityNlist = []
charitySumlist =[]

i = 1

while(i<4 and i>=1):
    charityName = raw_input("Please enter charity's name: ")
    charityNlist.append(charityName)
    i=i+1
    
print(charityNlist)
print("Enter charity of choice","1 =",charityNlist[0]," 2 =",charityNlist[1]," 3 =",charityNlist[2]," -1 to stop")
charitychoice = int(input("Enter charity of choice"))

while(charitychoice != -1):
    if(charitychoice<=3 and charitychoice>=1):
        bill = int(input("Pleae enter the amount of your bill: "))
        if(bill<=0):
            print("INVAILD amount")
        else:
            donation = bill/100
            charitySumlist.append(donation)
            print('$',donation,"donated to",charityNlist[charitychoice-1])
            print("Enter charity of choice","1 =",charityNlist[0]," 2 =",charityNlist[1]," 3 =",charityNlist[2]," -1 to stop")
            charitychoice = int(input("Enter charity of choice"))
if(charitychoice == -1):
    print(charitySumlist[0])
    print(charitySumlist[1])
    print(charitySumlist[2])
    total=charitySumlist[0]+charitySumlist[1]+charitySumlist[2]
    print(charityNlist[0],"$",charitySumlist[0],charityNlist[1],"$",charitySumlist[1],charityNlist[2],"$",charitySumlist[2],'Grand Total donated to charity:$',total)

    
#Current problem is not all the charitys have a donation the list will freak out
#doesnt add the things for a charity just adds more to list(Make own list for each charity outherwise wont work)
