from time import clock
et = clock()
# declere most of the varibles and lists
worklist = []
secworklist = []
totallist = []
worklist = range(10)
primepairlist = []
notprime = 0
num = 2
i = 0
secnum = -1
thirdnum = -1
totalnum = 0
countnum = 2
calcnum1 = 0
calcnum2 = 0
printchar1 = "and"
k = 0
none =  0
doesntmatter = ""

# This part of the code is the part to get a list of
# prime numbers to be used later

# The number is the while statment can be changed
# to the wanted amount of numbers to be calculated
while num != 100:
    # Add 1 to the previous so the same number is not repeted
    num = num + 1
    # For loop to calculate prime nubers
    for i in range(2, num):
        # If num remainder is 0 then dont do anything
        if (num % i) == 0:
            break
        else:
            secworklist.append(num)
            

        # If num remainder is not 0 then it adds the number to the second list

print(secworklist)



while countnum != 50:
    # Add 1 to the previous so the same number is not repeted
    countnum = countnum + 1

    if thirdnum < 50:
        secnum = secnum + 1
        thirdnum = secnum + 1
        calcnum1 = secworklist[secnum]
        calcnum2 = secworklist[thirdnum]
        totalnum = (calcnum1 + calcnum2 )- 1
    #print(totalnum)
    # print(secworklist[secnum])
        #print(secworklist[thirdnum])
      
    # For loop to calculate prime nubers
    for i in range(2, totalnum):
        # If num remainder is 0 then dont do anything

        if (totalnum % i) == 0:
            
            totallist.append(secworklist[secnum])
            totallist.append(printchar1)
            totallist.append(secworklist[thirdnum])
        
            
            
             
        


# This prints the finished list, It is only for testing purpose's
# print(secworklist)

print(len(totallist))
at = clock()
runtime = at-et
print(runtime)
