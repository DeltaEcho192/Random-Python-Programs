brick=0
can=0

brick=8*10*18
can=256*3.1415*28

can=can-brick
can=can/1000
can=can+0.000038
print(can)