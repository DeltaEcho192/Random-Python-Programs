import MySQLdb

# Open database connection
db = MySQLdb.connect("localhost","root","xxmaster","MostWanted" )

# prepare a cursor object using cursor() method
cursor = db.cursor()

# Prepare SQL query to INSERT a record into the database.
sql = "SELECT * FROM MostWanted_Total"
try:
   # Execute the SQL command
   cursor.execute(sql)
   # Fetch all the rows in a list of lists.
   results = cursor.fetchall()
   for row in results:
      firstname = row[0]
      dateofbirth = row[1]
      PlaceOfBirth = row[2]
      nationality = row[3]
      sex = row[4]
      bounty = row[5]
      cork = row[6]
      crime = row[7]
    
      # Now print fetched result
      print "firstname=%s,dateofbirth=%s,PlaceOfBirth=%s,nationality=%s,sex=%s,bounty=%s,cork=%s,crime=%s" % \
             (firstname, dateofbirth, PlaceOfBirth,nationality, sex, bounty,cork,crime )
except:
   print "Error: unable to fecth data"

# disconnect from server
db.close()
