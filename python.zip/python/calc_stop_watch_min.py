howmin = 0.5
amount = 1080000000.000000
amount = amount * howmin
print(amount)