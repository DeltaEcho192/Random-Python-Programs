print('Please put the text file in the same folder as this script')
inputvar = raw_input("Please enter name of file: ")
with open(inputvar) as f:
    print sum(1 for _ in f)