from time import clock

choice=int(input("Please enter 1 for first choice or 2 for second choice: "))

et = clock()
class A(object):
    def test2(self):
         test2="picked the wrong answer"
         print(test2)
    def test3(self):
        cost = 150
        amount = 0
        total = 0

        amount = int(input("Please enter the amount of credit would you like: "))

        total = amount / cost

        print("$", total, " ", amount)


class B(object):
    def show(self):
        print("hello from B")

if choice==1:
    a = A()
    print(a.test2())
    print(a.test3())
else:
    b = B()
    print(b.show())
at = clock()

runtime = at-et
print(runtime)