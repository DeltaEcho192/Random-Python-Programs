import os
file = open('outputmorse.txt','w')


a = "*-"
b = '-***'
c = '-*-*'
d = '-**'
e = '*'
f = '**-*'
g = '--*'
h = '****'
i = '**'
j = '*---'
k = '-*-'
l = '*-**'
m = '--'
n = '-*'
o = '---'
p = '*--*'
q = '--*-'
r = '*-*'
s = '***'
t = '-'
u = '**-'
v = '***-'
w = '*--'
x = '-**-'
y = '-*--'
z = '--**'
space = ' '

changed_str = ''

my_str = raw_input("Please enter your desired sentance:")

for char in my_str:
    if char == 'a':
        changed_str = changed_str + a
        changed_str = changed_str + space
        os.system('say "beep boop"')
    elif char == 'b':
        changed_str = changed_str + b
        changed_str = changed_str + space
        os.system('say "boop beep beep beep"')
    elif char == 'c':
        changed_str = changed_str + c
        changed_str = changed_str + space
        os.system('say "boop beep boop beep"')
    elif char == 'd':
        changed_str = changed_str + d
        changed_str = changed_str + space
        os.system('say "boop beep beep"')
    elif char == 'e':
        changed_str = changed_str + e
        changed_str = changed_str + space
        os.system('say "beep"')
    elif char == 'f':
        changed_str = changed_str + f
        changed_str = changed_str + space
        os.system('say "beep beep boop beep"')
    elif char == 'g':
        changed_str = changed_str + g
        changed_str = changed_str + space
        os.system('say "boop boop beep"')
    elif char == 'h':
        changed_str = changed_str + h
        changed_str = changed_str + space
        os.system('say "beep beep beep beep"')
    elif char == 'i':
        changed_str = changed_str + i
        changed_str = changed_str + space
        os.system('say "beep beep"')
    elif char == 'j':
        changed_str = changed_str + j
        changed_str = changed_str + space
        os.system('say "beep boop boop boop"')
    elif char == 'k':
        changed_str = changed_str + k
        changed_str = changed_str + space
        os.system('say "boop beep boop"')
    elif char == 'l':
        changed_str = changed_str + l
        changed_str = changed_str + space
        os.system('say "beep boop beep beep"')
    elif char == 'm':
        changed_str = changed_str + m
        changed_str = changed_str + space
        os.system('say "boop boop"')
    elif char == 'n':
        changed_str = changed_str + n
        changed_str = changed_str + space
        os.system('say "boop beep"')
    elif char == 'o':
        changed_str = changed_str + o
        changed_str = changed_str + space
        os.system('say "boop boop boop"')
    elif char == 'p':
        changed_str = changed_str + p
        changed_str = changed_str + space
        os.system('say "beep boop boop beep"')
    elif char == 'q':
        changed_str = changed_str + q
        changed_str = changed_str + space
        os.system('say "beep boop"')
    elif char == 'r':
        changed_str = changed_str + r
        changed_str = changed_str + space
        os.system('say "beep boop beep"')
    elif char == 's':
        changed_str = changed_str + s
        changed_str = changed_str + space
        os.system('say "beep beep beep"')
    elif char == 't':
        changed_str = changed_str + t
        changed_str = changed_str + space
        os.system('say "boop"')
    elif char == 'u':
        changed_str = changed_str + u
        changed_str = changed_str + space
        os.system('say "beep beep boop"')
    elif char == 'v':
        changed_str = changed_str + v
        changed_str = changed_str + space
        os.system('say "beep beep beep boop"')
    elif char == 'w':
        changed_str = changed_str + w
        changed_str = changed_str + space
        os.system('say "beep boop boop"')
    elif char == 'x':
        changed_str = changed_str + x
        changed_str = changed_str + space
        os.system('say "boop beep beep boop"')
    elif char == 'y':
        changed_str = changed_str + y
        changed_str = changed_str + space
        os.system('say "boop beep boop boop"')
    elif char == 'z':
        changed_str = changed_str + z
        changed_str = changed_str + space
        os.system('say "boop boop beep beep"')
        

file.write(changed_str)
file = open('outputmorse.txt','r')
print(file.read())
file.close()
