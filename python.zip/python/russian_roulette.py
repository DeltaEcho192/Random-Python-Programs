import random
from time import clock
import os

gunvar=random.randrange(1,7)
playerchoice=0
play1score=1
play2score=1
cont1=""
cont2=""
amountround=0
num=0

amountround=int(input("Please enter the amount of rounds you would like to play: "))

for i in range(1,amountround):
    playerchoice=int(input("1=Player1,2=Player2: "))
    if playerchoice == 1:
        gunvar=random.randrange(1,7)
        if gunvar % 6 ==0:
            print("BANG")
            os.system("say 'BANG'")
            play1score=0
        else:
            print("You live to play anouther round")
            if play1score == 0:
                play1score=1
            play1score=play1score*2
            print(play1score)
    
    else:
        gunvar=random.randrange(1,7)
        if gunvar % 6 ==0:
                print("BANG")
                os.system("say 'BANG'")
                play2score=0
        else:
            print("You live to play anouther round")
            if play2score == 0:
                play2score=1
            play2score=play2score*2 
            print(play2score)
at = clock()
runtime = at
print(runtime)