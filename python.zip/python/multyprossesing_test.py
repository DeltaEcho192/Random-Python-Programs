import multiprocessing 
def worker(): 
    """worker function""" 
    num = num + 1
    return 
if __name__ == '__main__': 
    jobs = [] 
    for i in range(10): 
        p = multiprocessing.Process(target=worker) 
        jobs.append(p) 
        p.start()

