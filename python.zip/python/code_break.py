amount = 1000000
totrange = range(1,amount)
print(len(totrange))
code =  int(input("Enter a code: "))
code1 = 0
i = 1
while i != totrange:
    if i != code:
        i = i + 1
    else:
        break
print(i)