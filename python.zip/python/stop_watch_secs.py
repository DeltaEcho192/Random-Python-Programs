from time import clock
import os

class A(object):
    def clock(self):
        
        
        howsec = int(input("How many seconds: "))
        
        at = clock()
        amount = 17500000
        amount = amount * howsec
        num = 0
        while amount != num:
                num=num+1
        et = clock()
        
        os.system("say 'STOP'")
        return "runtime: %.4f sec" % (et-at)
        
    
   
   
a = A()
#print(a.clock)
print(a.clock())