import random
from time import clock
et = clock()
pray=random.randrange(1,3)
print("Pray and does it work")
if pray == 1:
    print("yes")
    print("Praise the lord")
else:
    print("no")
    print("God works in mysterious ways")
at = clock()
runtime = at-et
print(runtime)