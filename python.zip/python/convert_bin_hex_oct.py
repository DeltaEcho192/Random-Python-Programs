dec=50

print("This is your number in decimal",dec)
print(bin(dec),"this is in binary")
print(hex(dec),"This is in hexadecimal")
print(oct(dec),"This is in octal")