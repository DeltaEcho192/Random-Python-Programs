decode=""
my_str="test "


for char in my_str:
    if char=="a":
        char='h'
        decode=decode+char
    elif char=="b":
        char="l"
        decode=decode+char
    elif char=="c":
         char="j"
         decode=decode+char
    elif char=="d":
        char="f"
        decode=decode+char
    elif char=='e':
         char='y'
         decode=decode+char
    elif char=='f':
         char='a'
         decode=decode+char
    elif char=='g':
         char='e'
         decode=decode+char
    elif char=='h':
         char='x'
         decode=decode+char
    elif char=='i':
         char='m'
         decode=decode+char
    elif char=='j':
         char='b'
         decode=decode+char
    elif char=='k':
         char='z'
         decode=decode+char
    elif char=='l':
         char='p'
         decode=decode+char
    elif char=='m':
         char='o'
         decode=decode+char
    elif char=='n':
         char='v'
         decode=decode+char
    elif char=='o':
         char='u'
         decode=decode+char
    elif char=='p':
         char='w'
         decode=decode+char
    elif char=='q':
         char='d'
         decode=decode+char
    elif char=='s':
         char='k'
         decode=decode+char
    elif char=='t':
         char='q'
         decode=decode+char
    elif char=='u':
         char='r'
         decode=decode+char
    elif char=='w':
         char='i'
         decode=decode+char
    elif char=='x':
         char='g'
         decode=decode+char
    elif char=='y':
         char='n'
         decode=decode+char
    elif char=='z':
         char='t'
         decode=decode+char
        
print(decode)
        